-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2025 at 08:47 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `governorate` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `block` int(11) NOT NULL,
  `street` varchar(255) NOT NULL,
  `house_number` int(11) NOT NULL,
  `special_instructions` text DEFAULT NULL,
  `payment_method` varchar(50) NOT NULL,
  `status` enum('Pending','Confirmed','Delivered') DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `item_id` int(11) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `alttxt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `alttxt`) VALUES
(1, 'Apple iPhone 16 Pro 1TB Phone - Desert Titanium (One Physical nano SIM + One eSIM)', 'Screen size: 6.3 inch, Processor: A18 Pro chip with New 6-core GPU, Apple Intelligence, Pro camera system (48MP Fusion, 48MP Ultra Wide, and 12MP 5x Telephoto), Front camera: 12MP, External Buttons: Action button, Camera controls: Exposure, Depth, Zoom, Cameras, Styles, Tone, Up to 27 hours video playback, USB-C, MagSafe: Wireless charging up to 25W with 30W adapter or higher, OS: iOS18', 489.90, 'The image displays an Apple iPhone 15 Pro in gold, showcasing both front and back views. The front view features the screen with an abstract wallpaper consisting of circular shapes in golden and brown tones. The back view highlights the Apple logo and the'),
(2, 'Apple iPhone 16 Pro Max 512GB Phone - Black Titanium (One Physical nano SIM + One eSIM)', 'Screen size: 6.9 inch, Processor: A18 Pro chip with New 6-core GPU, Apple Intelligence, Pro camera system (48MP Fusion, 48MP Ultra Wide, and 12MP 5x Telephoto), Front camera: 12MP, External Buttons: Action button, Camera controls: Exposure, Depth, Zoom, Cameras, Styles, Tone, Up to 33 hours video playback, USB-C, MagSafe: Wireless charging up to 25W with 30W adapter or higher, OS: iOS18', 424.90, 'The image displays an Apple iPhone, specifically the iPhone 16 Pro Max model. It is showcased from both the front and back views. The front features a sleek screen with a dark abstract wallpaper, composed of overlapping circular gradients. The back of the'),
(3, 'Apple iPhone 16 128GB Phone - Teal (One Physical nano SIM + One eSIM)', 'Screen size: 6.1 inch, Processor: A18 chip with new 6 core CPU, Apple intelligence, External Buttons: Action button, Camera controls: Exposure, Depth, Zoom, Cameras, Styles, Tone, Camera: 48MP Fusion, 12MP Ultra Wide, and 12MP 2x Telephoto, Front: 12MP, USB-C, Up to 22 hours video playback, MagSafe wireless charging up to 25W with 30W adapter or higher, OS: iOS 18', 239.90, 'The image shows an Apple iPhone 16 in teal color. The phone features a storage capacity of 128GB and supports one physical nano SIM and one eSIM. Its design highlights a sleek, modern appearance, reflecting the premium quality of the device'),
(4, 'Samsung Galaxy S24+ 256GB 12GB RAM Phone - Onyx Black', 'Screen size: 6.7 inch, Connectivity: 5G+Wifi, Storage: 256 GB, RAM: 12 GB, Processor: Exynos 2400, Battery Capacity: 4900 mAh, Rear Camera: 50MP (F1.8)+10MP (F2.4)+12MP (F2.2), Front Camera: 12MP (F 2.2)', 204.90, 'The image displays the Samsung Galaxy S24+ in Onyx Black color. This smartphone features a sleek and modern design, with a large bezel-less display and a centered punch-hole front camera for a seamless look. The back showcases three vertically aligned cam');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD UNIQUE KEY `unique_order_product` (`order_id`,`product_id`),
  ADD UNIQUE KEY `item_id` (`item_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
