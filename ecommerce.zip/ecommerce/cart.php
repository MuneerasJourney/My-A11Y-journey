<?php
require 'db_connection.php';
session_start(); // Start or resume the session


if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["product_id"])) {
    // Generate a session-based order ID if not already set


    if (!isset($_SESSION['order_id'])) {
        $_SESSION['order_id'] = uniqid('', true);
        $_SESSION['item']=0;
    }

    // Get product ID and default quantity
    $product_id = intval($_POST["product_id"]);
    $_SESSION['item'] =$_SESSION['item']+1;
    $quantity = 1; // Default quantity for new items

    // Check if the product is already in the cart
    $check_cart = $conn->prepare("SELECT * FROM order_items WHERE product_id = ? AND order_id = ?");
    $check_cart->bind_param("is", $product_id, $_SESSION['order_id']);
    $check_cart->execute();
    $result = $check_cart->get_result();

    if ($result->num_rows > 0) {
        // Update quantity if the product exists in the cart
        $update_cart = $conn->prepare("UPDATE order_items SET quantity = quantity + 1 WHERE product_id = ? AND order_id = ?");
        $update_cart->bind_param("is", $product_id, $_SESSION['order_id']);
        $update_cart->execute();
        $update_cart->close();
    } else {
        // Add new product to the cart
        $add_to_cart = $conn->prepare("INSERT INTO order_items (item_id,order_id, product_id, quantity) VALUES (?,?, ?, ?)");
        $add_to_cart->bind_param("issi",  $_SESSION['item'],$_SESSION['order_id'], $product_id, $quantity);
        $add_to_cart->execute();
        $add_to_cart->close();
    }

    $check_cart->close();
    $conn->close();

    // Redirect back to the products page
    header("Location: products.php");
    exit;
}
?>
