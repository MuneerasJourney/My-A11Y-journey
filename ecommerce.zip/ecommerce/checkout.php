<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Accessible checkout page for an online shop">
  <title>Accessible Checkout</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

  <style>
  /* Enhance focus visibility */
  input:focus, button:focus {
    outline: 3px solid #0056b3;
    outline-offset: 2px;
    box-shadow: 0 0 5px rgba(0, 86, 179, 0.75);
  }
  .sr-only {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    border: 0;
  }
</style>


</head>
<?php
// db_connection.php
session_start();
 include("header.php");
$host = "localhost";
$user = "root";
$password = "";
$dbname = "shop_db";

// Establish database connection
$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['order_id'])) {
    echo "<div class='alert alert-danger' role='alert'>No active order found.</div>";
    exit;
}
?>

<body>
    <header class="bg-light p-3 text-center">
        <h1>Accessible Shop - Checkout</h1>
        <p>Complete your purchase with accessibility in mind</p>
    </header>

    <main class="container mt-4" id="main-content">
        <form action="process_checkout.php" method="POST" aria-labelledby="checkout-heading">
            <h2 id="checkout-heading" class="text-primary">Checkout</h2>

            <!-- Customer Information Section -->
            <fieldset>
                <legend>Customer Information</legend>

                <div class="form-group">
                    <label for="name">Name <span class="text-danger">*</span></label>
                    <input type="text" id="name" name="name" class="form-control" required aria-required="true" aria-describedby="nameHelp">
                    <small id="nameHelp" class="form-text text-muted">Enter your full name.</small>
                </div>

                <div class="form-group">
                    <label for="email">Email <span class="text-danger">*</span></label>
                    <input type="email" id="email" name="email" class="form-control" required aria-required="true" aria-describedby="emailHelp">
                    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                </div>

                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" name="phone" class="form-control" aria-describedby="phoneHelp">
                    <small id="phoneHelp" class="form-text text-muted">Optional - Enter your contact number.</small>
                </div>

            </fieldset>
            <fieldset>
                <legend>Delivery Address</legend>

                <!-- Governorate Dropdown -->
                <div class="form-group">
                    <label for="governorate">Select Governorate <span class="text-danger">*</span></label>
                    <select id="governorate" name="governorate" class="form-control" required onchange="updateCities()">
                        <option value="" disabled selected>Select a governorate</option>
                        <option value="Capital">Capital</option>
                        <option value="Hawalli">Hawalli</option>
                        <option value="Farwaniya">Farwaniya</option>
                        <option value="Ahmadi">Ahmadi</option>
                        <option value="Jahra">Jahra</option>
                        <option value="Mubarak Al-Kabeer">Mubarak Al-Kabeer</option>
                    </select>
                </div>

                <!-- City Dropdown (Updated Dynamically) -->
                <div class="form-group">
                    <label for="city">Select City <span class="text-danger">*</span></label>
                    <select id="city" name="city" class="form-control" required>
                        <option value="" disabled selected>Select a city</option>
                    </select>
                </div>

                <!-- Block Input (Must be a Number) -->
                <div class="form-group">
                    <label for="block">Block <span class="text-danger">*</span></label>
                    <input type="number" id="block" name="block" class="form-control" required>
                </div>

                <!-- Street Input -->
                <div class="form-group">
                    <label for="street">Street <span class="text-danger">*</span></label>
                    <input type="text" id="street" name="street" class="form-control" required>
                </div>

                <!-- House Number Input (Must be a Number) -->
                <div class="form-group">
                    <label for="house_number">House Number <span class="text-danger">*</span></label>
                    <input type="number" id="house_number" name="house_number" class="form-control" required>
                </div>

                <!-- Special Instructions -->
                <div class="form-group">
                    <label for="special_instructions">Special Instructions</label>
                    <textarea id="special_instructions" name="special_instructions" class="form-control"></textarea>
                </div>

            </fieldset>
            <!-- Updated Payment Information Section -->
            <fieldset>
                <legend>Payment Information</legend>
                <label>
                    <input type="radio" name="payment_method" value="cash_on_delivery" checked>
                    Cash on Delivery
                </label>
            </fieldset>

            <!-- Submit Button -->
            <button type="submit" class="btn btn-success btn-block" aria-label="Complete your purchase with cash on delivery">
                Complete Purchase
            </button>
        </form>
    </main>

    <footer class="bg-dark text-white text-center py-3">
        <p>&copy; 2025 Phone Haven. All rights reserved.</p>
    </footer>

    <script>
        // Move focus programmatically to the form when the page loads
        document.addEventListener("DOMContentLoaded", () => {
            const checkoutForm = document.querySelector("form");
            if (checkoutForm) {
                checkoutForm.focus();
            }
        });



        function updateCities() {
    let governorate = document.getElementById("governorate").value;
    let cityDropdown = document.getElementById("city");
    cityDropdown.innerHTML = "<option value='' disabled selected>Select a city</option>"; // Reset options

    const citiesByGovernorate = {
        "Capital": ["Kuwait City", "Sharq", "Bneid Al-Gar", "Dasman"],
        "Hawalli": ["Salmiya", "Hawalli", "Bayan", "Rumaithiya"],
        "Farwaniya": ["Farwaniya", "Khaitan", "Ardiya", "Jleeb Al-Shuyoukh"],
        "Ahmadi": ["Mangaf", "Fahaheel", "Mahboula", "Egaila"],
        "Jahra": ["Jahra", "Al-Naeem", "Qasr", "Saad Al-Abdullah"],
        "Mubarak Al-Kabeer": ["Al-Qurain", "Sabah Al-Salem", "Adan", "Al-Masayel"]
    };

    if (citiesByGovernorate[governorate]) {
        citiesByGovernorate[governorate].forEach(city => {
            let option = document.createElement("option");
            option.value = city;
            option.textContent = city;
            cityDropdown.appendChild(option);
        });
    }
}
    </script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
