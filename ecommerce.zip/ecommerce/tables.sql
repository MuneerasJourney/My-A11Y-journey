CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    image_url VARCHAR(255) NOT NULL,
    alttxt VARCHAR(255) NOT NULL,
    available_quantity INT NOT NULL DEFAULT 0
);





CREATE TABLE orders (
    order_id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,  -- Added phone number field
    governorate VARCHAR(100) NOT NULL,
    city VARCHAR(100) NOT NULL,
    block INT NOT NULL,
    street VARCHAR(255) NOT NULL,
    house_number INT NOT NULL,
    special_instructions TEXT,
    payment_method VARCHAR(50) NOT NULL,
    status ENUM('Pending', 'Confirmed', 'Delivered') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE order_items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id VARCHAR(50) NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);


CREATE TABLE contact_us (
    id INT AUTO_INCREMENT PRIMARY KEY, -- Unique ID for each message
    name VARCHAR(100) NOT NULL,       -- User's name
    email VARCHAR(150) NOT NULL,      -- User's email
    message TEXT NOT NULL,            -- User's message
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP -- Timestamp of submission
);
