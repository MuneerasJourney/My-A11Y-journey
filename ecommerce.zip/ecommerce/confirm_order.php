<?php
require 'db_connection.php'; // Include database connection
 include("header.php");

// Check if an order_id is provided via GET
if (isset($_GET['order_id'])) {
    $order_id = $_GET['order_id'];

    // Update the status of the order in the database
    $sql = "UPDATE orders SET status = 'Confirmed' WHERE order_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $order_id);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) { ?>
            <header class="bg-light p-3 text-center">
                <h1>Order Confirmation</h1>
                <p>Thank you for confirming your order!</p>
            </header>

            <main class="container mt-4" id="main-content" role="main">
                <div class="alert alert-success" role="alert" aria-live="polite">
                    Thank you for confirming your order. Your order is now being prepared!
                </div>
                <p>You will receive an update when your order is ready for delivery.</p>
            </main>

        <?php } else { ?>
            <div aria-live="assertive" class="alert alert-danger" role="alert">
                Invalid order ID or the order has already been confirmed.
            </div>
        <?php }
    } else { ?>
        <header class="bg-light p-3 text-center">
            <h1>Order Issue</h1>
            <p>We encountered a problem with your order.</p>
        </header>

        <main class="container mt-4" id="main-content" role="main">
            <div class="alert alert-danger" role="alert" aria-live="assertive">
                Invalid order ID or the order has already been confirmed.
            </div>
            <p>Please ensure that you have entered the correct order details.</p>
        </main>
    <?php }

    $stmt->close();
} else { ?>
    <header class="bg-light p-3 text-center">
        <h1>Order Issue</h1>
        <p>We encountered a problem with your order.</p>
    </header>

    <main class="container mt-4" id="main-content" role="main">
        <div class="alert alert-danger" role="alert" aria-live="assertive">
            No order ID provided. Please check the confirmation link.
        </div>
    </main>

<?php } // Closing the last if-condition properly

$conn->close(); // Close the database connection
?>
<footer class="bg-dark text-white text-center py-3">
    <p>&copy; 2025 Phone Haven. All rights reserved.</p>
</footer>
