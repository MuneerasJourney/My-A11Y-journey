<?php
// Include PHPMailer's autoload file for modern compatibility
require 'db_connection.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php'; // This is crucial for error handling in newer versions
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

        $mail = new PHPMailer(true); // Instantiate PHPMailer with exception handling



            if ($_SERVER["REQUEST_METHOD"] === "POST") {
                // Collect and sanitize form inputs
                $name = htmlspecialchars(strip_tags($_POST['name']));
                $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
                $message = htmlspecialchars(strip_tags($_POST['message']));

                // Validate inputs
                if (!empty($name) && !empty($email) && !empty($message)) {
                    try {
                        // Create PHPMailer instance
                        $mail = new PHPMailer(true);

                        // SMTP settings
                        $mail->isSMTP();
                        $mail->Host = 'smtp.gmail.com'; // Specify SMTP server
                        $mail->SMTPAuth = true;
                        $mail->Username = ''; // SMTP username
                        $mail->Password = ''; // SMTP password (avoid hardcoding sensitive data)
                        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Use TLS encryption
                        $mail->Port = 587; // TLS port

                        // Sender and recipient settings
                        $mail->setFrom($mail->Username, 'Accessible Shop');
                        $mail->addAddress($email, $name); // Add the recipient

                        // Email content
                        $mail->isHTML(true);
                        $mail->Subject = 'Message Received';
                        $mail->Body = "
                          <!DOCTYPE html>
                          <html lang='en'>
                          <head>
                              <meta charset='UTF-8'>
                              <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                              <title>Contact Confirmation</title>
                          </head>
                          <body style='font-family: Arial, sans-serif; line-height: 1.6;'>
                              <table style='width: 100%; border-collapse: collapse;'>
                                  <tr>
                                      <td style='background-color: #f4f4f4; padding: 20px; text-align: center;'>
                                          <h1 style='color: #333;'>Accessible Shop</h1>
                                          <p style='color: #555;'>Thank you for reaching out to us!</p>
                                      </td>
                                  </tr>
                                  <tr>
                                      <td style='padding: 20px;'>
                                          <p>Hello <strong>$name</strong>,</p>
                                          <p>We’ve received your message and appreciate you contacting us:</p>
                                          <blockquote style='border-left: 4px solid #ccc; margin: 10px 0; padding: 10px; color: #555;'>$message</blockquote>
                                          <p>Our team will review your message and get back to you as soon as possible. If you have urgent questions, feel free to reach us directly at <strong>support@accessible-shop.com</strong>.</p>
                                          <p>Thank you for trusting us. We’re here to help!</p>
                                          <p>Best regards,</p>
                                          <p>The Accessible Shop Team</p>
                                      </td>
                                  </tr>
                                  <tr>
                                      <td style='background-color: #f4f4f4; padding: 20px; text-align: center;'>
                                          <p>&copy; 2025 Accessible Shop. All rights reserved.</p>
                                      </td>
                                  </tr>
                              </table>
                          </body>
                          </html>
                        ";

                        // Send the email
                        if ($mail->send()) {
                            $stmt = $conn->prepare("INSERT INTO contact_us (name, email, message) VALUES (?, ?, ?)");
                            $stmt->bind_param("sss", $name, $email, $message); // Bind parameters
                            // Execute the query and check for success
                            if ($stmt->execute()) {
                                echo "Thank you, $name! Your message has been received successfully.";
                            } else {
                                echo "Error: Unable to save your message. Please try again.";
                            }
                        } else {
                            echo "Error: Unable to send confirmation email. Please try again later.";
                        }
                    } catch (Exception $e) {
                        echo "Error: " . $mail->ErrorInfo;
                    }
                } else {
                    echo "Please fill in all the required fields.";
                }
            } else {
                echo "Invalid request method.";
            }

    $stmt->close();


$conn->close();
// Redirect back to the products page
header("Location: index.php");
exit;
?>
