<?php
// Include PHPMailer's autoload file for modern compatibility
require 'db_connection.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php'; // This is crucial for error handling in newer versions

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
session_start();


$name = htmlspecialchars($_POST["name"]);
$email = htmlspecialchars($_POST["email"]);
$phone = htmlspecialchars($_POST["phone"]);
$governorate = htmlspecialchars($_POST["governorate"]);
$city = htmlspecialchars($_POST["city"]);
$block = htmlspecialchars($_POST["block"]);
$street = htmlspecialchars($_POST["street"]);
$house_number = htmlspecialchars($_POST["house_number"]);
$special_instructions = htmlspecialchars($_POST["special_instructions"]);
$payment_method = "Cash on Delivery"; // Predefined payment method
$status = 'Pending';

// Generate a unique order ID and confirmation link
$order_id = $_SESSION['order_id']; // Generating a more robust unique ID
$confirm_link = "confirm_order.php?order_id=" . urlencode($order_id);

// Insert order into the database
$sql = "INSERT INTO orders (order_id, name, email, phone, governorate, city, block, street, house_number, special_instructions, payment_method, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

// Correct the bind_param format to match your table fields
$stmt->bind_param(
    "ssssssississ",
    $order_id,
    $name,
    $email,
    $phone,
    $governorate,
    $city,
    $block,
    $street,
    $house_number,
    $special_instructions,
    $payment_method,
    $status
);


    if ($stmt->execute()) {
        $mail = new PHPMailer(true); // Instantiate PHPMailer with exception handling

        try {


            // SMTP settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com'; // Specify SMTP server
            $mail->SMTPAuth = true;
            $mail->Username = ''; // SMTP username
            $mail->Password = ''; // SMTP password (avoid hardcoding sensitive data)
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Use TLS encryption
            $mail->Port = 587; // TLS port

            // Sender and recipient settings
            $mail->setFrom($mail->Username, 'Accessible Shop');
            $mail->addAddress($email, $name); // Add the recipient

            // Email content
              $mail->isHTML(true);
              $mail->Subject = 'Order Confirmation';
              $mail->Body = "
              <!DOCTYPE html>
              <html lang='en'>
              <head>
                  <meta charset='UTF-8'>
                  <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                  <title>Order Confirmation</title>
              </head>
              <body style='font-family: Arial, sans-serif; line-height: 1.6;'>
                  <table style='width: 100%; border-collapse: collapse;'>
                      <tr>
                          <td style='background-color: #f4f4f4; padding: 20px; text-align: center;'>
                              <h1 style='color: #333;'>Accessible Shop</h1>
                              <p style='color: #555;'>Thank you for placing an order with us!</p>
                          </td>
                      </tr>
                      <tr>
                          <td style='padding: 20px;'>
                              <h2 style='color: #333;'>Order Confirmation</h2>
                              <p>Hello <strong>$name</strong>,</p>
                              <p>We have received your order and are preparing it for delivery. Please confirm your order details below:</p>
                              <ul>
                                  <li><strong>Order ID:</strong> $order_id</li>
                                  <li><strong>Name:</strong> $name</li>
                                  <li><strong>Email:</strong> $email</li>
                                  <li><strong>Phone Number:</strong> $phone</li>
                                  <li><strong>Delivery Address:</strong> Block $block, $street, $city, $governorate</li>
                                  <li><strong>Payment Method:</strong> $payment_method</li>
                                  <li><strong>Status:</strong> $status</li>
                              </ul>
                              <p>If all the details are correct, please confirm your order by clicking the link below:</p>
                              <p><a href='http://localhost/ecommerce/".$confirm_link."' style='background-color: #28a745; color: #fff; padding: 10px 15px; text-decoration: none; border-radius: 5px;'>Confirm Your Order</a></p>
                              <p>If the above link does not work, copy and paste this URL into your browser:</p>
                              <p><code>'http://localhost/ecommerce/".$confirm_link."'</code></p>
                              <p>If you have any questions, feel free to reply to this email or contact us directly.</p>
                              <p>Best regards,</p>
                              <p>The Accessible Shop Team</p>
                          </td>
                      </tr>
                      <tr>
                          <td style='background-color: #f4f4f4; padding: 20px; text-align: center;'>
                              <p>&copy; 2025 Accessible Shop. All rights reserved.</p>
                          </td>
                      </tr>
                  </table>
              </body>
              </html>
              ";
            // Send email
            $mail->send();
            echo "<div aria-live='assertive' class='alert alert-success' role='alert'>Email has been sent successfully!</div>";
        } catch (Exception $e) {
            echo "<div aria-live='assertive' class='alert alert-danger' role='alert'>";
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            echo "</div>";
        }
    } else {
        echo "<div id='order-error' aria-live='assertive' class='alert alert-danger' role='alert'>";
        echo "Error placing the order. Please try again.";
        echo "</div>";
    }

    $stmt->close();


$conn->close();

unset($_SESSION['order_id'] );
unset($_SESSION['item']);
session_destroy();
header("Location: orderRecieved.php");

?>
