<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Accessible Shopping Cart</title>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
  body {
    font-size: 18px;
    line-height: 1.5;
  }
  button:focus, input:focus {
    outline: 3px solid #007bff;
    outline-offset: 2px;
  }
  .cart-item img {
    max-width: 80px;
    height: auto;
  }
  </style>
</head>
<?php
session_start();
require 'db_connection.php';
 include("header.php");
// Retrieve current order ID
$order_id = $_SESSION['order_id'] ?? '';
$total =0;
if (!$order_id) {
    echo "<div class='alert alert-danger' role='alert'>No active order found.</div>";
    exit;
}

// Fetch cart items
$sql = "SELECT oi.item_id,p.id ,p.name, p.price, oi.quantity, p.alttxt
        FROM order_items oi
        JOIN products p ON oi.product_id = p.id
        WHERE oi.order_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $order_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<body>
    <header class="bg-light p-3 text-center">
        <h1 id="cart-title">Your Shopping Cart</h1>
        <p>Review your order before proceeding.</p>
    </header>

    <main class="container mt-4" role="main">
        <?php if ($result->num_rows > 0): ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">Image</th>
                        <th scope="col">Product Name</th>
                        <th scope="col">Price</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr class="cart-item">
                            <td>
                                <img src="img/<?=$row['id']?>.jpeg"
                                     alt="<?= htmlspecialchars($row['alttxt']) ?>"
                                     class="img-fluid">
                            </td>
                            <td><?= htmlspecialchars($row['name']) ?></td>
                            <td>$<?= number_format($row['price'], 2) ?></td>
                            <td><?= intval($row['quantity']) ?></td>
                            <?php $total += $row['price'] *$row['quantity']  ?>
                            <td>
                                <form action="delete_cart.php" method="POST">
                                    <input type="hidden" name="item_id" value="<?= $row['id'] ?>">
                                    <button type="submit" class="btn btn-danger" aria-label="Remove <?= htmlspecialchars($row['name']) ?>">
                                        Remove
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
                <tr>
                  <td colspan="4"><b>Total price<b></td>
                  <td><?= $total ?> </td>
                </tr>
            </table>

            <a href="checkout.php" class="btn btn-success" role="button">Proceed to Checkout</a>
        <?php else: ?>
            <div class="alert alert-info" role="alert">
                Your cart is empty. Start shopping!
            </div>
        <?php endif; ?>
    </main>

    <footer class="bg-dark text-white text-center py-3">
        <p>&copy; 2025 Phone Haven. All rights reserved.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
