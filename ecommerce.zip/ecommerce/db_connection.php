<?php
// Database connection settings
$host = "localhost";        // Hostname, typically "localhost"
$user = "root";             // Database username
$password = "";             // Database password
$dbname = "shop_db";        // Name of the database

// Create a connection
$conn = new mysqli($host, $user, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Optionally, you can use this connection in other files by including `db_connection.php`.
?>
