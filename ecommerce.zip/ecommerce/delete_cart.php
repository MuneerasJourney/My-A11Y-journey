<?php
require 'db_connection.php'; // Include database connection
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Query to delete item from the cart
    $sql = "DELETE FROM order_items WHERE order_id = ? AND product_id = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
$stmt->bind_param("si", $_SESSION['order_id'], $_POST['item_id']);
        if ($stmt->execute()) {
            echo "Item removed successfully!";
            header("Location: ShowCart.php"); // Redirect back to cart
            exit();
        } else {
            echo "Error: Could not delete the item.";
        }

        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
}

$conn->close();
?>
