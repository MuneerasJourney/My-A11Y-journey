<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
    /* Improved color contrast for links */
    a.nav-link {
        color: #004085; /* Darker blue for higher contrast */
    }
    a.nav-link:focus, a.nav-link:hover {
        color: #0056b3;
        text-decoration: underline;
    }
    /* Style for focus outlines on interactive elements */
    a:focus, button:focus, input:focus, select:focus {
          outline: 3px solid #0056b3; /* Bright blue focus outline */
          outline-offset: 2px;
          box-shadow: 0 0 5px rgba(0, 86, 179, 0.75); /* Adds a glow effect */
      }
      /* Add focus styles */
a:focus, button:focus, input:focus {
outline: 3px solid #0056b3;
outline-offset: 2px;
box-shadow: 0 0 5px rgba(0, 86, 179, 0.75);
}

</style>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="index.php">Phone Haven</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link text-dark" href="products.php">Products</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-dark" href="ShowCart.php">Cart</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-dark" href="checkout.php">Check out</a>
            </li>
        </ul>
    </div>
</nav>

<script>
    // Form validation for enhanced accessibility
    function validateForm(form) {
        const product_id = form.product_id.value;
        if (!product_id) {
            alert("Product ID is missing. Please try again.");
            return false;
        }
        return true;
    }

    // Ensure focus moves to the alert message
      document.addEventListener("DOMContentLoaded", () => {
          const alertMessage = document.getElementById("cart-message");
          if (alertMessage) {
              alertMessage.focus();
          }
      });
      function announce(message) {
        const liveRegion = document.getElementById("live-region");
        liveRegion.textContent = message;
    }

</script>
