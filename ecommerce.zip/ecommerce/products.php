<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Accessible shopping cart with search functionality">
    <title>Accessible Shop with Search</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <!-- Skip to Content Link -->
    <a href="#main-content" class="sr-only sr-only-focusable">Skip to Content</a>

    <?php include("header.php");
    require 'db_connection.php';
 ?>

    <main id="main-content" class="container mt-4">
        <!-- Search Bar Section -->
        <section id="search">
            <form method="GET" action="" class="form-inline mb-4" role="search" aria-label="Product search form">
                <label for="search-bar" class="sr-only">Search for products:</label>
                <input type="text" id="search-bar" name="query" class="form-control mr-2"
                       placeholder="Search for a product"
                       value="<?php echo isset($_GET['query']) ? htmlspecialchars($_GET['query']) : ''; ?>"
                       aria-placeholder="Enter product name or description" aria-describedby="search-help">
                <button type="submit" class="btn btn-primary" aria-label="Submit search">Search</button>
                <p id="search-help" class="sr-only">You can search by product name or description.</p>
            </form>
        </section>

        <!-- Products Section -->
        <section id="products">
            <h1 class="text-primary">Products</h1>
            <div class="row">
                <?php
                // Fetch search query, if provided
                $searchQuery = isset($_GET['query']) ? $conn->real_escape_string($_GET['query']) : '';

                // Fetch products from the database based on the search query
                $sql = "SELECT * FROM products";
                if (!empty($searchQuery)) {
                    $sql .= " WHERE name LIKE '%$searchQuery%' OR description LIKE '%$searchQuery%'";
                }

                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="col-md-4 mb-3">
                                <div class="card h-100">
                                    <img src="img/' . $row["id"] . '.jpeg" class="card-img-top" alt="' . htmlspecialchars($row["alttxt"]) . '">
                                    <div class="card-body">
                                        <h5 class="card-title">' . htmlspecialchars($row["name"]) . '</h5>
                                        <p class="card-text">Price: $' . htmlspecialchars($row["price"]) . '</p>
                                        <form action="cart.php" method="POST" onsubmit="return validateForm(this)">
                                            <input type="hidden" name="product_id" value="' . $row["id"] . '">
                                            <button type="submit" class="btn btn-primary btn-block">Add to Cart</button>
                                        </form>
                                    </div>
                                </div>
                              </div>';
                    }
                } else {
                    echo '<p>No products found.</p>';
                }
                ?>
            </div>
        </section>
    </main>

    <footer class="bg-dark text-white text-center py-3">
        <p>&copy; 2025 Phone Haven. All rights reserved.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
