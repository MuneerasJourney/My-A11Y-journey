<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Your one-stop shop for the latest smartphones at unbeatable prices. Find the perfect phone for you today!">
    <title>Phone Haven - Accessible Smartphone Store - main page</title>
      <?php include("header.php"); ?>
</head>
<body>
    <!-- Header Section -->
    <header class="bg-dark text-white text-center py-5">
        <h1>Welcome to Phone Haven</h1>
        <p>Your ultimate destination for the latest smartphones at unbeatable prices.</p>
        <a href="products.php" class="btn btn-primary">Shop Now</a>
    </header>

    <!-- search Section -->
    <section id="search" style="background-color: #121212; color: white; text-align: center; display: flex; justify-content: center; align-items: center; flex-direction: column; min-height: 100vh;">
        <h1 style="font-size: 3rem; font-weight: bold; margin-bottom: 1.5rem;">Search Products</h1>
        <form method="GET" action="products.php" class="form-inline mb-4" role="search" aria-label="Product search form">
            <label for="search-bar" class="sr-only">Search for products:</label>
            <input type="text" id="search-bar" name="query" class="form-control mr-2"
                   placeholder="Search for a product"
                   value="<?php echo isset($_GET['query']) ? htmlspecialchars($_GET['query']) : ''; ?>"
                   aria-placeholder="Enter product name or description" aria-describedby="search-help">
            <button type="submit" class="btn btn-primary" aria-label="Submit search">Search</button>
            <p id="search-help" class="sr-only">You can search by product name or description.</p>
        </form>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="container my-5">
        <h2 class="text-center mb-4">Contact Us</h2>
        <form action="contact_us.php" method="post" aria-labelledby="contactForm" onsubmit="return validateContactForm();">
            <fieldset>
                <legend id="contactForm" class="visually-hidden">Contact Us Form</legend>
                <div class="mb-3">
                    <label for="name" class="form-label">Name <span class="text-danger">(Required)</span>:</label>
                    <input type="text" id="name" name="name" class="form-control" required aria-required="true" aria-describedby="nameHelp nameError" aria-invalid="false">
                    <div id="nameHelp" class="form-text">Please enter your full name.</div>
                    <div id="nameError" class="form-text text-danger" style="display: none;" aria-live="assertive"></div>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email <span class="text-danger">(Required)</span>:</label>
                    <input type="email" id="email" name="email" class="form-control" required aria-required="true" aria-describedby="emailHelp emailError" aria-invalid="false">
                    <div id="emailHelp" class="form-text">We’ll never share your email with anyone else.</div>
                    <div id="emailError" class="form-text text-danger" style="display: none;" aria-live="assertive"></div>
                </div>
                <div class="mb-3">
                    <label for="message" class="form-label">Message <span class="text-danger">(Required)</span>:</label>
                    <textarea id="message" name="message" rows="4" class="form-control" required aria-required="true" aria-describedby="messageHelp messageError" aria-invalid="false"></textarea>
                    <div id="messageHelp" class="form-text">Feel free to share your questions or comments with us.</div>
                    <div id="messageError" class="form-text text-danger" style="display: none;" aria-live="assertive"></div>
                </div>
                <button type="submit" class="btn btn-primary">Send Message</button>
            </fieldset>
        </form>
    </section>

    <!-- Footer Section -->
    <footer class="bg-dark text-white text-center py-3">
        <p>&copy; 2025 Phone Haven. All rights reserved.</p>
    </footer>
<script type="text/javascript">
    function validateContactForm() {
        let isValid = true;

        // Name Validation
        const nameInput = document.getElementById('name');
        const nameError = document.getElementById('nameError');
        if (nameInput.value.trim() === '') {
            nameError.textContent = 'Please enter your name.';
            nameError.style.display = 'block';
            nameInput.setAttribute('aria-invalid', 'true');
            nameInput.focus();
            isValid = false;
        } else {
            nameError.textContent = '';
            nameError.style.display = 'none';
            nameInput.setAttribute('aria-invalid', 'false');
        }

        // Email Validation
        const emailInput = document.getElementById('email');
        const emailError = document.getElementById('emailError');
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(emailInput.value.trim())) {
            emailError.textContent = 'Please enter a valid email address.';
            emailError.style.display = 'block';
            emailInput.setAttribute('aria-invalid', 'true');
            emailInput.focus();
            isValid = false;
        } else {
            emailError.textContent = '';
            emailError.style.display = 'none';
            emailInput.setAttribute('aria-invalid', 'false');
        }

        // Message Validation
        const messageInput = document.getElementById('message');
        const messageError = document.getElementById('messageError');
        if (messageInput.value.trim() === '') {
            messageError.textContent = 'Please enter a message.';
            messageError.style.display = 'block';
            messageInput.setAttribute('aria-invalid', 'true');
            messageInput.focus();
            isValid = false;
        } else {
            messageError.textContent = '';
            messageError.style.display = 'none';
            messageInput.setAttribute('aria-invalid', 'false');
        }
        return isValid;
    }

</script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
