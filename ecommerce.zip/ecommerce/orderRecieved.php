<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Order confirmation page with email verification instructions">
    <title>Confirm Your Email</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-size: 18px;
            line-height: 1.5;
        }
        button:focus {
            outline: 3px solid #007bff;
            outline-offset: 2px;
        }
    </style>
    <?php include("header.php"); ?>

</head>
<body>
    <header class="bg-light p-3 text-center">
        <h1>Order Confirmation</h1>
        <p>Please confirm your email to process your order.</p>
    </header>

    <main class="container mt-4" id="main-content" role="main">
        <div class="alert alert-info" role="alert" aria-live="polite">
            An email has been sent to your registered email address. Please check your inbox and click the confirmation link to proceed with your order.
        </div>
        <p>If you haven’t received the email, please check your spam or junk folder.</p>


    </main>

    <footer class="bg-dark text-white text-center py-3">
        <p>&copy; 2025 Phone Haven. All rights reserved.</p>
    </footer>

    <script>
        // Programmatic focus on the alert when the page loads
        document.addEventListener("DOMContentLoaded", () => {
            const alert = document.querySelector(".alert");
            if (alert) {
                alert.focus();
            }
        });
    </script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
